FactoryBot.define do
  factory :category_question do
    category_id { 1 }
    question_id { 1 }
  end
end
