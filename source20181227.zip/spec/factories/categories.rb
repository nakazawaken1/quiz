FactoryBot.define do
  factory :category do
    name { "カテゴリテスト" }
  end
end
