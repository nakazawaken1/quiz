require 'selenium-webdriver'
driver = Selenium::WebDriver.for :chrome